clear(); clc();

printf("Metodo da decomposição - LU e Crout\n");
printf("Resolução direta de sistema de equações lineares \n");

// Dados de entrada - matriz A e vetor B
printf("\nDados de entrada - matriz A e vetor B:\n");
A = [ 3,  2, -1,  1;
      2, -2,  4, -3;
      1,  1,  1, -1;
      2,  3,  1,  4];
B = [10; 7; 6; 15];
// B = [9; 11; 8; 21]

T = A // Salva a matriz original para verificacao
printf("\nEntrada - Matriz A (original):\n");
disp(A);

printf("\nEntrada - Vetor B (original):\n");
disp(B);

printf("\nFatoração:\n");
n = length(B);
printf("\nDimensão da Matriz A: %d x %d\n", n, n);
L = zeros(n,n);
U = zeros(n,n);

// A diagonal de U é unitaria por Crout
for j = 1:n
  U(j,j) = 1;
end

for j = 1:n
  // Cálculo da matriz L (elementos da coluna j)
  for i = j:n
    SomaLu = 0;
    for k = 1:j-1
      SomaLu = SomaLu + L(i,k)*U(k,j);
    end
    L(i,j) = A(i,j) - SomaLu;
  end
  
  // Trava de segurança contra divisão por zero
  if L(j,j) == 0 then
      error("Pivô nulo encontrado. O método sem pivoteamento falhou.");
  end

  // Cálculo da matriz U (elementos da linha j)
  for i = (j+1):n
    SomaLu = 0;
    for k = 1:j-1
      SomaLu = SomaLu + L(j,k)*U(k,i);
    end
    U(j, i) = (A(j, i) - SomaLu) / L(j,j);
  end
end

printf("Saida - Fator L:\n");
disp(L);
printf("Saida - Fator U:\n");
disp(U);

printf("\n ----------- substituição progressiva ------------:");
Y = zeros(n, 1);
// Pre-alocando o vetor Y para melhor performance
if L(1,1) == 0 then
  error("Erro: pivo nulo durante a subst progressiva");
end
Y(1) = B(1) / L(1,1);

for i = 2:n
  SomaLY = 0;
  for j = 1:i-1
      SomaLY = SomaLY + L(i,j)*Y(j);
  end
    if L(i,i) == 0 then
      error("Erro: pivo nulo durante a subst progressiva");
    end
    Y(i) = (B(i) - SomaLY) / L(i,i);
end

// Dados de saida - solucao Y
printf("\nSolução Y (LY = B) do sistema:\n");
disp(Y);

printf("\nSubstituição retroativa:\n");
X = zeros(n,1);
X(n) = Y(n);
for i = (n-1):-1:1
  SomaUX = 0;
  for j = (i+1):n
      SomaUX = SomaUX + U(i,j)*X(j);
  end
    X(i) = Y(i) - SomaUX;
end

printf("\nSolução X (UX = Y) do sistema:\n");
mprintf(" %g\n", X);

printf("\nVerificação da solução :\n");
for i = 1:n
    s = 0;
    for j = 1:n
        s = s + (T(i,j) * X(j));
        if (j < n) then
            printf("(%g * %.6f) + ", T(i,j), X(j));
        else
            printf("(%g * %.6f) = %.6f\n", T(i,j), X(j), s);
        end
    end
end
printf("\nFIM\n");
